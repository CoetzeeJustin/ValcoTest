﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Configuration;
using System.Data;

namespace dotnetApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LoadFarms();
        }

        private void LoadFarms()
        {
            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TestDB"].ConnectionString);
            {
                SqlCommand cmd = new SqlCommand("SELECT Farm FROM FlockPlacements GROUP BY Farm", conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    cbx_Farms.Items.Add(reader["Farm"].ToString());
                }

                reader.Close();
            }
        }

        private void CloseApplication(object sender, RoutedEventArgs e)
        {
            System.Windows.Application.Current.Shutdown();
        }

        private void LoadNewFlocks(object sender, SelectionChangedEventArgs e)
        {
            cbx_Flocks.Items.Clear();
            cbx_Flocks.SelectedItem = null;
            dg_Placements.ItemsSource = null;

            SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TestDB"].ConnectionString);
            {
                SqlCommand cmd = new SqlCommand($"SELECT Flock FROM FlockPlacements WHERE Farm='{cbx_Farms.SelectedItem.ToString()}' GROUP BY Flock", conn);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    cbx_Flocks.Items.Add(reader["Flock"].ToString());
                }

                reader.Close();
            }
        }

        private void LoadPlacements(object sender, SelectionChangedEventArgs e)
        {
            if (cbx_Flocks.SelectedItem != null)
            {   
                dg_Placements.ItemsSource = null;

                SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["TestDB"].ConnectionString);
                {
                    SqlCommand cmd = new SqlCommand($"SELECT * FROM FlockPlacements WHERE Flock='{cbx_Flocks.SelectedItem.ToString()}'", conn);
                    conn.Open();
                    DataTable dt = new DataTable();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dt);
                    dg_Placements.ItemsSource = dt.DefaultView;
                }
            }

        }
    }
}
